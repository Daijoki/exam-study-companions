# CIP® Exam Study Companion

Interactive study tool for CIP (Certified IRB Professional) exam preparation.

## Features
- **Documents**: Federal regulations, ethical codes, and guidance documents
- **Glossary**: Searchable terms with regulatory citations and flashcard mode
- **Historical Foundations**: Timeline of landmark cases and regulatory milestones
- **Knowledge Checks**: Practice questions aligned with the CIP® Content Outline

## Structure
```
CIP/
├── index.html          # Main application
├── css/
│   └── styles.css      # Consolidated stylesheet (includes dark mode)
├── js/                 # Application modules
│   ├── main.js         # App controller
│   ├── state-manager.js
│   ├── glossary.js
│   ├── documents.js
│   ├── historical.js
│   ├── quiz.js
│   └── ...
├── data/               # JSON data files
│   ├── glossary.json
│   ├── documents.json
│   ├── historical-foundations.json
│   └── quiz.json
└── docs/               # Document detail pages
```

## Usage
1. Open `index.html` in a web browser
2. Navigate between tabs to access different study resources
3. Use the theme toggle (🌙/☀️) for dark/light mode
4. Progress is saved locally in your browser

## Version
Clean build - December 2024
