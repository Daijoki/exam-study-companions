// Theme Toggle Functionality
// Respects user preference, system preference, and provides smooth transitions

(function() {
    'use strict';
    
    const STORAGE_KEY = 'primr-theme-preference';
    
    // Get theme preference from storage or system
    function getPreferredTheme() {
        const storedTheme = localStorage.getItem(STORAGE_KEY);
        if (storedTheme) {
            return storedTheme;
        }
        
        // Check system preference
        if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
            return 'dark';
        }
        
        return 'light';
    }
    
    // Apply theme to document
    function applyTheme(theme) {
        document.documentElement.setAttribute('data-theme', theme);
        
        // Update toggle button icon if it exists
        const themeToggle = document.getElementById('theme-toggle');
        if (themeToggle) {
            updateToggleIcon(theme);
            updateToggleAria(theme);
        }
    }
    
    // Update toggle button icon
    function updateToggleIcon(theme) {
        const sunIcon = document.getElementById('sun-icon');
        const moonIcon = document.getElementById('moon-icon');
        
        if (sunIcon && moonIcon) {
            if (theme === 'dark') {
                sunIcon.style.display = 'block';
                moonIcon.style.display = 'none';
            } else {
                sunIcon.style.display = 'none';
                moonIcon.style.display = 'block';
            }
        }
    }
    
    // Update ARIA attributes
    function updateToggleAria(theme) {
        const themeToggle = document.getElementById('theme-toggle');
        if (themeToggle) {
            const newTheme = theme === 'dark' ? 'light' : 'dark';
            themeToggle.setAttribute('aria-label', `Switch to ${newTheme} mode`);
        }
    }
    
    // Toggle theme
    function toggleTheme() {
        const currentTheme = document.documentElement.getAttribute('data-theme') || 'light';
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        
        localStorage.setItem(STORAGE_KEY, newTheme);
        applyTheme(newTheme);
        
        // Announce to screen readers
        announceThemeChange(newTheme);
    }
    
    // Announce theme change to screen readers
    function announceThemeChange(theme) {
        const announcement = document.createElement('div');
        announcement.setAttribute('role', 'status');
        announcement.setAttribute('aria-live', 'polite');
        announcement.className = 'sr-only';
        announcement.textContent = `Switched to ${theme} mode`;
        document.body.appendChild(announcement);
        
        setTimeout(() => {
            document.body.removeChild(announcement);
        }, 1000);
    }
    
    // Apply theme immediately (before page renders)
    const initialTheme = getPreferredTheme();
    applyTheme(initialTheme);
    
    // Setup toggle button after DOM loads
    document.addEventListener('DOMContentLoaded', function() {
        const themeToggle = document.getElementById('theme-toggle');
        
        if (themeToggle) {
            // Set initial state
            const currentTheme = document.documentElement.getAttribute('data-theme') || 'light';
            updateToggleIcon(currentTheme);
            updateToggleAria(currentTheme);
            
            // Add click listener
            themeToggle.addEventListener('click', toggleTheme);
            
            // Add keyboard support
            themeToggle.addEventListener('keydown', function(event) {
                if (event.key === 'Enter' || event.key === ' ') {
                    event.preventDefault();
                    toggleTheme();
                }
            });
        }
        
        // Listen for system theme changes
        if (window.matchMedia) {
            const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
            mediaQuery.addEventListener('change', function(e) {
                // Only auto-switch if user hasn't set a preference
                if (!localStorage.getItem(STORAGE_KEY)) {
                    applyTheme(e.matches ? 'dark' : 'light');
                }
            });
        }
    });
    
    // Expose toggle function globally for potential external use
    window.toggleTheme = toggleTheme;
})();
